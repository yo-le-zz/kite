use std::fs;
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

use iced::widget::{button, checkbox, column, container, row, text, text_input};
use iced::{window, Element, Task};

mod metadata;

const KITE_ICON: &[u8] = include_bytes!("../assets/logo/256/kite-256.png");

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
struct InstallMetadata {
    version: String,
    install_path: String,
    installed_at: String,
    os: String,
    arch: String,
}

#[allow(dead_code)]
#[derive(Debug, Clone)]
enum InstallationState {
    NotInstalled,
    Installed {
        path: PathBuf,
        version: String,
        installed_at: String,
    },
    Broken {
        path: PathBuf,
        message: String,
    },
}

#[derive(Debug, Clone)]
enum Message {
    Install,
    Uninstall,
    RefreshStatus,
    PathChanged(String),
    ToggleDesktopShortcut(bool),
    ToggleStartMenu(bool),
}

struct Installer {
    title: String,
    install_path: String,
    desktop_shortcut: bool,
    start_menu: bool,
    status: String,
    install_state: InstallationState,
}

fn default_install_dir() -> PathBuf {
    if cfg!(windows) {
        dirs::data_local_dir()
            .unwrap_or_else(|| dirs::home_dir().unwrap_or_else(|| PathBuf::from(".")))
            .join("Kite")
    } else if cfg!(target_os = "macos") {
        dirs::home_dir()
            .unwrap_or_else(|| PathBuf::from("."))
            .join("Applications")
            .join("Kite")
    } else {
        dirs::data_local_dir()
            .unwrap_or_else(|| dirs::home_dir().unwrap_or_else(|| PathBuf::from(".")))
            .join("Kite")
    }
}

fn format_timestamp() -> String {
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default();
    let secs = now.as_secs();
    let ts = chrono::DateTime::<chrono::Utc>::from_timestamp(secs as i64, 0)
        .unwrap_or_else(|| chrono::DateTime::<chrono::Utc>::from_timestamp(0, 0).unwrap());
    ts.format("%Y-%m-%d %H:%M:%S UTC").to_string()
}

fn detect_installation_state(dir: &Path) -> InstallationState {
    let marker = dir.join(".kite-installed.json");
    match fs::read_to_string(&marker) {
        Ok(contents) => match serde_json::from_str::<InstallMetadata>(&contents) {
            Ok(metadata) => InstallationState::Installed {
                path: dir.to_path_buf(),
                version: metadata.version,
                installed_at: metadata.installed_at,
            },
            Err(err) => InstallationState::Broken {
                path: dir.to_path_buf(),
                message: format!("installation marker is corrupted: {err}"),
            },
        },
        Err(err) if err.kind() == std::io::ErrorKind::NotFound => InstallationState::NotInstalled,
        Err(err) => InstallationState::Broken {
            path: dir.to_path_buf(),
            message: format!("unable to inspect installation state: {err}"),
        },
    }
}

#[allow(dead_code)]
fn install_kite(dir: &Path) -> anyhow::Result<()> {
    install_kite_with_options(dir, true, true)
}

fn install_kite_with_options(
    dir: &Path,
    create_desktop_shortcuts: bool,
    create_start_menu: bool,
) -> anyhow::Result<()> {
    fs::create_dir_all(dir)?;

    let icon_path = dir.join("kite-icon.png");
    fs::write(&icon_path, KITE_ICON)?;

    let marker = dir.join(".kite-installed.json");
    let metadata = InstallMetadata {
        version: metadata::VERSION.to_string(),
        install_path: dir.to_string_lossy().to_string(),
        installed_at: format_timestamp(),
        os: metadata::OS.to_string(),
        arch: metadata::ARCH.to_string(),
    };
    fs::write(&marker, serde_json::to_string_pretty(&metadata)?)?;

    let launcher_path = dir.join(if cfg!(windows) { "kite-launcher.bat" } else { "kite-launcher" });
    let app_path = std::env::current_exe()?.display().to_string();
    if cfg!(windows) {
        fs::write(&launcher_path, format!("@echo off\r\nstart \"\" \"{app_path}\"\r\n"))?;
    } else {
        fs::write(
            &launcher_path,
            format!("#!/usr/bin/env sh\nexec \"{app_path}\" \"$@\"\n"),
        )?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let mut permissions = fs::metadata(&launcher_path)?.permissions();
            permissions.set_mode(0o755);
            fs::set_permissions(&launcher_path, permissions)?;
        }
    }

    if create_desktop_shortcuts {
        create_desktop_shortcut(dir, &icon_path)?;
    }

    if create_start_menu {
        create_start_menu_shortcut(dir, &icon_path)?;
    }

    Ok(())
}

fn uninstall_kite(dir: &Path) -> anyhow::Result<()> {
    let marker = dir.join(".kite-installed.json");
    if marker.exists() {
        fs::remove_file(&marker)?;
    }

    for entry in [
        dir.join("kite-launcher"),
        dir.join("kite-launcher.bat"),
        dir.join("kite-icon.png"),
        dir.join("Kite.desktop"),
        dir.join("kite.desktop"),
    ] {
        if entry.exists() {
            let _ = fs::remove_file(entry);
        }
    }

    if dir.exists() {
        let remaining = fs::read_dir(dir)?.count();
        if remaining == 0 {
            fs::remove_dir(dir)?;
        }
    }

    Ok(())
}

fn create_desktop_shortcut(dir: &Path, icon_path: &Path) -> anyhow::Result<()> {
    if cfg!(windows) {
        let shortcut = dir.join("Kite-Desktop-Shortcut.bat");
        let exe = std::env::current_exe()?.display().to_string();
        fs::write(shortcut, format!("@echo off\r\nstart \"\" \"{exe}\"\r\n"))?;
        return Ok(());
    }

    let desktop_file = dir.join("Kite.desktop");
    let exec = dir.join("kite-launcher").display().to_string();
    let icon = icon_path.display().to_string();
    let file = format!(
        "[Desktop Entry]\nVersion=1.0\nType=Application\nName=Kite\nComment=Launch Kite\nExec={exec}\nIcon={icon}\nTerminal=false\nCategories=Utility;Application;\n"
    );
    fs::write(&desktop_file, file)?;

    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let mut permissions = fs::metadata(&desktop_file)?.permissions();
        permissions.set_mode(0o755);
        fs::set_permissions(&desktop_file, permissions)?;
    }

    Ok(())
}

fn create_start_menu_shortcut(dir: &Path, icon_path: &Path) -> anyhow::Result<()> {
    let entry = dir.join("kite.desktop");
    let exec = dir.join("kite-launcher").display().to_string();
    let icon = icon_path.display().to_string();
    let content = format!(
        "[Desktop Entry]\nVersion=1.0\nType=Application\nName=Kite\nComment=Launch Kite\nExec={exec}\nIcon={icon}\nTerminal=false\nCategories=Utility;Application;\n"
    );
    fs::write(entry, content)?;
    Ok(())
}

pub fn main() -> iced::Result {
    let initial_dir = default_install_dir();
    let initial_state = detect_installation_state(&initial_dir);
    iced::application(|state: &Installer| state.title.clone(), update, view)
        .window(window::Settings {
            size: iced::Size::new(860.0, 560.0),
            resizable: false,
            icon: load_icon(),
            ..Default::default()
        })
        .run_with(move || {
            let message = match &initial_state {
                InstallationState::Installed { version, .. } => format!("Kite {} is already installed.", version),
                InstallationState::Broken { message, .. } => format!("Detected a broken installation: {message}"),
                InstallationState::NotInstalled => "Kite is not installed yet.".to_string(),
            };

            (
                Installer {
                    title: format!(
                        "{} Installer {} ({} - {})",
                        metadata::NAME,
                        metadata::VERSION,
                        metadata::ARCH,
                        metadata::OS
                    ),
                    install_path: initial_dir.to_string_lossy().to_string(),
                    desktop_shortcut: true,
                    start_menu: true,
                    status: message,
                    install_state: initial_state,
                },
                Task::none(),
            )
        })
}

fn load_icon() -> Option<window::icon::Icon> {
    window::icon::from_file_data(KITE_ICON, None).ok()
}

fn update(state: &mut Installer, message: Message) -> Task<Message> {
    match message {
        Message::PathChanged(path) => {
            state.install_path = path;
            state.install_state = detect_installation_state(Path::new(&state.install_path));
            state.status = match &state.install_state {
                InstallationState::Installed { version, .. } => format!("Kite {} already installed at {}.", version, state.install_path),
                InstallationState::Broken { message, .. } => format!("Broken install at {}: {message}", state.install_path),
                InstallationState::NotInstalled => format!("Ready to install into {}.", state.install_path),
            };
        }
        Message::ToggleDesktopShortcut(value) => {
            state.desktop_shortcut = value;
        }
        Message::ToggleStartMenu(value) => {
            state.start_menu = value;
        }
        Message::Install => {
            let result = install_kite_with_options(Path::new(&state.install_path), state.desktop_shortcut, state.start_menu);
            match result {
                Ok(()) => {
                    state.install_state = detect_installation_state(Path::new(&state.install_path));
                    state.status = format!("Installation completed successfully in {}.", state.install_path);
                }
                Err(err) => {
                    state.install_state = InstallationState::Broken {
                        path: PathBuf::from(&state.install_path),
                        message: err.to_string(),
                    };
                    state.status = format!("Installation failed: {err}");
                }
            }
        }
        Message::Uninstall => {
            let dir = Path::new(&state.install_path);
            let result = uninstall_kite(dir);
            match result {
                Ok(()) => {
                    state.install_state = detect_installation_state(dir);
                    state.status = format!("Kite was uninstalled from {}.", state.install_path);
                }
                Err(err) => {
                    state.install_state = InstallationState::Broken {
                        path: dir.to_path_buf(),
                        message: err.to_string(),
                    };
                    state.status = format!("Uninstall failed: {err}");
                }
            }
        }
        Message::RefreshStatus => {
            state.install_state = detect_installation_state(Path::new(&state.install_path));
            state.status = match &state.install_state {
                InstallationState::Installed { version, .. } => format!("Kite {} is installed at {}.", version, state.install_path),
                InstallationState::Broken { message, .. } => format!("Issue detected: {message}"),
                InstallationState::NotInstalled => format!("Ready to install into {}.", state.install_path),
            };
        }
    }

    Task::none()
}

fn view(state: &Installer) -> Element<'_, Message> {
    let state_label = match &state.install_state {
        InstallationState::Installed { version, .. } => format!("Installed ({version})"),
        InstallationState::Broken { .. } => "Needs attention".to_string(),
        InstallationState::NotInstalled => "Not installed".to_string(),
    };

    let header = row![
        container(text("K").size(36)).padding(10),
        column![
            text(state.title.clone()).size(26),
            text(format!("Target directory: {}", state.install_path)).size(16),
            text(format!("Status: {}", state_label)).size(14)
        ]
    ]
    .padding(iced::Padding::new(12.0));

    let options = column![
        text("Installation options").size(18),
        text_input("Custom install directory", &state.install_path)
            .on_input(Message::PathChanged)
            .padding(8),
        checkbox("Create desktop shortcut", state.desktop_shortcut)
            .on_toggle(Message::ToggleDesktopShortcut),
        checkbox("Create start menu entry", state.start_menu)
            .on_toggle(Message::ToggleStartMenu)
    ]
    .spacing(8)
    .padding(iced::Padding::new(8.0));

    let actions = row![
        button("Install Kite").on_press(Message::Install),
        button("Uninstall").on_press(Message::Uninstall),
        button("Refresh").on_press(Message::RefreshStatus)
    ]
    .spacing(12)
    .padding(iced::Padding::new(8.0));

    let content = column![header, text(state.status.clone()).size(16).width(760), options, actions];

    container(content).padding(20).into()
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::time::{SystemTime, UNIX_EPOCH};

    #[test]
    fn default_install_dir_uses_platform_specific_path() {
        let dir = default_install_dir();
        assert!(!dir.as_os_str().is_empty());
        assert!(dir.to_string_lossy().contains("Kite") || dir.to_string_lossy().contains("kite"));
    }

    #[test]
    fn detect_installation_state_returns_installed_for_marker_file() {
        let temp = std::env::temp_dir().join(format!(
            "kite-installer-test-{}",
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let _ = fs::remove_dir_all(&temp);
        fs::create_dir_all(&temp).unwrap();
        fs::write(
            temp.join(".kite-installed.json"),
            "{\"version\":\"0.1.0\",\"install_path\":\"/tmp/kite\",\"installed_at\":\"2026-01-01\",\"os\":\"linux\",\"arch\":\"x86_64\"}",
        )
        .unwrap();

        let state = detect_installation_state(&temp);
        assert!(matches!(state, InstallationState::Installed { .. }));

        let _ = fs::remove_dir_all(&temp);
    }

    #[test]
    fn install_creates_marker_and_launcher() {
        let temp = std::env::temp_dir().join(format!(
            "kite-installer-install-{}",
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let _ = fs::remove_dir_all(&temp);

        install_kite(&temp).unwrap();

        assert!(temp.join(".kite-installed.json").exists());
        assert!(temp.join("kite-launcher").exists() || temp.join("kite-launcher.bat").exists());

        let _ = fs::remove_dir_all(&temp);
    }
}